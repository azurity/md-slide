window.addEventListener('load', function() {
    mermaid.initialize({ sttartObLoad: true, securityLevel: 'loose' })
})
